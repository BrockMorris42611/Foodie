/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.Restaurant;

public class StringData {
    public String restaurantId   = "";
    public String latLong        = "";
    public String address        = "";
    public String details        = "";
    public String restaurantName = "";
    public String errorMsg       = "";

    // default constructor leaves all data members with empty string.
    public StringData() {
    }
    public String toString() {
        return ", Restaurant Id: " + this.restaurantId
                + ", Restaurant Name: " + this.restaurantName;
    }
    public int getCharacterCount() {
        String s = this.restaurantId + this.latLong + this.address + this.details
                + this.restaurantName;
        return s.length();
    }
}
