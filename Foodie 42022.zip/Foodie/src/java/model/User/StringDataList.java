/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.User;

import java.util.ArrayList;

/**
 *
 * @author 17854
 */
public class StringDataList {
    public String dbError = "";
    public ArrayList<StringData> userList = new ArrayList();

    // Default constructor leaves StringDataList objects nicely set with properties 
    // indicating no database error and 0 elements in the list.
    public StringDataList() {
    }

    // Adds one StringData element to the array list of StringData elements
    public void add(StringData stringData) {
        this.userList.add(stringData);
    }
}
