/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.User;

/**
 *
 * @author 17854
 */
public class StringData {
    public String userId     = "";
    public String email      = "";
    public String username   = "";
    public String password   = "";
    public String errorMsg   = "";
    
    
    // default constructor leaves all data members with empty string.
    public StringData() {
    }
    public String toString() {
        return ", User Id: " + this.userId
                + ", Username: " + this.username;
    }
    public int getCharacterCount() {
        String s = this.userId + this.email + this.username + this.password
                + this.errorMsg;
        return s.length();
    }
}
